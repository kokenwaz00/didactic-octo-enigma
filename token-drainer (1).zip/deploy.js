const fs = require("fs");
const path = require("path");
const { ethers } = require("ethers");
const { Chain } = require("./chain");

// Deploys Token and TokenPuller to the configured RPC and prints the
// addresses. Run with: RPC_URL=... PRIVATE_KEY=... node deploy.js
async function main() {
  const rpcUrl = process.env.RPC_URL || "http://127.0.0.1:8545";
  const privateKey = process.env.PRIVATE_KEY;
  if (!privateKey) {
    console.error("Set PRIVATE_KEY to deploy.");
    process.exit(1);
  }

  const provider = new ethers.JsonRpcProvider(rpcUrl);
  const wallet = new ethers.Wallet(privateKey, provider);
  console.log("Deployer:", wallet.address);

  const tokenArtifact = JSON.parse(
    fs.readFileSync(path.join(__dirname, "artifacts/contracts/Token.sol/Token.json"), "utf8")
  );
  const token = await new ethers.ContractFactory(
    tokenArtifact.abi,
    tokenArtifact.bytecode,
    wallet
  ).deploy(ethers.parseEther("1000000"));
  await token.waitForDeployment();
  console.log("Token:", await token.getAddress());

  const pullerArtifact = JSON.parse(
    fs.readFileSync(path.join(__dirname, "artifacts/contracts/TokenPuller.sol/TokenPuller.json"), "utf8")
  );
  const puller = await new ethers.ContractFactory(
    pullerArtifact.abi,
    pullerArtifact.bytecode,
    wallet
  ).deploy(await token.getAddress(), wallet.address);
  await puller.waitForDeployment();
  console.log("TokenPuller:", await puller.getAddress());
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
