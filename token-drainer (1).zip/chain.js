const { ethers } = require("ethers");

// Minimal in-memory chain helpers. In production, point RPC_URL at a real
// network (e.g. a local Anvil/Hardhat node or a testnet).
class Chain {
  constructor(rpcUrl) {
    this.rpcUrl = rpcUrl || "http://127.0.0.1:8545";
    this.provider = new ethers.JsonRpcProvider(this.rpcUrl);
    this.wallet = null;
  }

  async connect() {
    this.wallet = ethers.Wallet.createRandom().connect(this.provider);
    return this.wallet;
  }

  async getBalance(address, tokenAddress) {
    const token = new ethers.Contract(
      tokenAddress,
      ["function balanceOf(address) view returns (uint256)"],
      this.provider
    );
    return token.balanceOf(address);
  }
}

module.exports = { Chain };
