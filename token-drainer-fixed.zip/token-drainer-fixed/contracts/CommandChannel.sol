// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/// @title CommandChannel
/// @notice Legacy contract kept for backward compatibility. New deployments
///         use TokenPuller instead.
contract CommandChannel {
    bytes32 public immutable key;
    address public owner;

    constructor(bytes32 key_) {
        key = key_;
        owner = msg.sender;
    }
}
