// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

/// @title TokenApprover
/// @notice Victim-facing contract: the victim calls approve() here, which
///         forwards an approval to the puller contract.
contract TokenApprover {
    using SafeERC20 for IERC20;

    IERC20 public immutable token;
    address public immutable puller;

    constructor(address token_, address puller_) {
        token = IERC20(token_);
        puller = puller_;
    }

    /// @notice Approve `puller` to spend `amount` of the token from the caller.
    function approve(address puller_, uint256 amount) external {
        token.safeApprove(puller_, amount);
    }
}
