require("dotenv").config();
const hre = require("hardhat");
const { ethers } = hre;

const TOKEN_ADDRESS = process.env.TOKEN_ADDRESS;

async function main() {
  // Validate TOKEN_ADDRESS before doing anything.
  if (!TOKEN_ADDRESS) {
    console.error("ERROR: TOKEN_ADDRESS is not set. Export it before deploying.");
    process.exit(1);
  }
  if (!ethers.isAddress(TOKEN_ADDRESS)) {
    console.error(`ERROR: TOKEN_ADDRESS "${TOKEN_ADDRESS}" is not a valid address.`);
    process.exit(1);
  }

  const [deployer] = await ethers.getSigners();
  console.log("Deploying TokenPuller with:", deployer.address);
  console.log("Token:", TOKEN_ADDRESS);

  // Deploy TokenPuller with the real token address (matches chain.js at runtime).
  const TokenPuller = await ethers.getContractFactory("TokenPuller");
  const puller = await TokenPuller.deploy(TOKEN_ADDRESS);
  await puller.waitForDeployment();
  const pullerAddress = await puller.getAddress();

  console.log("\n=== Deployment complete ===");
  console.log("Puller address:", pullerAddress);
  console.log("Token address: ", TOKEN_ADDRESS);
  console.log("Chain ID:      ", (await ethers.provider.getNetwork()).chainId.toString());
  console.log("\nSet PULLER_ADDRESS=" + pullerAddress + " in your .env");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
