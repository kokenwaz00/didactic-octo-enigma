const { ethers } = require("hardhat");
require("dotenv").config();

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying with:", deployer.address);

  const key = ethers.hexlify(ethers.randomBytes(32));
  console.log("Channel key (32 bytes):", key);

  const channel = await ethers.deployContract("CommandChannel", [key]);
  await channel.waitForDeployment();
  console.log("CommandChannel:", await channel.getAddress());

  const chainId = Number((await ethers.provider.getNetwork()).chainId);
  console.log("chainId:", chainId);

  const config = {
    channel: await channel.getAddress(),
    key,
    chainId,
    token: process.env.TOKEN_ADDRESS || "0x0000000000000000000000000000000000000000",
  };
  console.log("Config:", JSON.stringify(config, null, 2));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
