// SPDX-License-Identifier: MIT
pragma solidity 0.8.19;

contract CommandChannel {
    address public owner;
    bytes32 public configHash;
    bool public active;

    event ChannelActivated(address indexed owner, bytes32 configHash);
    event ConfigUpdated(bytes32 newHash);
    event ChannelClosed();

    constructor(bytes memory _encryptedConfig) {
        owner = msg.sender;
        configHash = keccak256(_encryptedConfig);
        active = true;
        emit ChannelActivated(owner, configHash);
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "not owner");
        _;
    }

    function updateConfig(bytes memory _encryptedConfig) external onlyOwner {
        configHash = keccak256(_encryptedConfig);
        emit ConfigUpdated(configHash);
    }

    function close() external onlyOwner {
        active = false;
        emit ChannelClosed();
    }
}
