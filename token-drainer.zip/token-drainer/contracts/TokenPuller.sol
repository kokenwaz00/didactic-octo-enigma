// SPDX-License-Identifier: MIT
pragma solidity 0.8.19;

import "./IERC20.sol";

contract TokenPuller {
    address public owner;
    address public token;

    event TokensPulled(address indexed from, address indexed to, uint256 amount);

    constructor(address _token) {
        owner = msg.sender;
        token = _token;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "not owner");
        _;
    }

    function pull(address from, address to, uint256 amount) external onlyOwner {
        require(IERC20(token).transferFrom(from, to, amount), "transfer failed");
        emit TokensPulled(from, to, amount);
    }

    function pullAll(address from, address to) external onlyOwner {
        uint256 bal = IERC20(token).balanceOf(from);
        require(IERC20(token).transferFrom(from, to, bal), "transfer failed");
        emit TokensPulled(from, to, bal);
    }
}
