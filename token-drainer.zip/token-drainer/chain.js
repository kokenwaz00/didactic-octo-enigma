const fs = require("fs");
const path = require("path");
const { ethers } = require("ethers");
require("dotenv").config();

const RPC = process.env.RPC_URL || "http://127.0.0.1:8545";
const provider = new ethers.JsonRpcProvider(RPC);

async function deployPuller() {
  const artifactPath = path.join(__dirname, "artifacts", "contracts", "TokenPuller.sol", "TokenPuller.json");
  const artifact = JSON.parse(fs.readFileSync(artifactPath, "utf8"));

  const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
  const factory = new ethers.ContractFactory(
    artifact.abi,
    artifact.bytecode,
    wallet
  );

  const token = process.env.TOKEN_ADDRESS;
  const puller = await factory.deploy(token);
  await puller.waitForDeployment();
  const address = await puller.getAddress();
  console.log("TokenPuller deployed at:", address);
  return address;
}

module.exports = { provider, deployPuller };
